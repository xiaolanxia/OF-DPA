setpci -s 00:14.3 VENDOR_ID+0x4a.B=0x0c
